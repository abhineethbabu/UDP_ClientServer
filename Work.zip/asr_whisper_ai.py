import argparse
import io
import os
import speech_recognition as sr
import whisper
import torch
import socket
import os
import random

from time import sleep
from datetime import datetime, timedelta
from datetime import date
from queue import Queue
from tempfile import NamedTemporaryFile
from time import sleep
from sys import platform
from difflib import SequenceMatcher

# devices
_mlp = "assets/tts-wav/mlp.wav"
_iam = "assets/tts-wav/iam.wav"

# command
_pbit = "assets/tts-wav/pbit.wav"
_check = "assets/tts-wav/check.wav"

# status
_ok = "assets/tts-wav/ok.wav"
_not = "assets/tts-wav/not.wav"
_result = "assets/tts-wav/result.wav"
_sw = "assets/tts-wav/sw.wav"
_version = "assets/tts-wav/version.wav"
_revision = "assets/tts-wav/revision.wav"
_date = "assets/tts-wav/date.wav"
_cpu = "assets/tts-wav/cpu.wav"
_sdram = "assets/tts-wav/sdram.wav"
_ace_ram = "assets/tts-wav/ace_ram.wav"

# numbers
_zero = "assets/tts-wav/0.wav"
_one = "assets/tts-wav/1.wav"
_two = "assets/tts-wav/2.wav"
_three = "assets/tts-wav/3.wav"
_four = "assets/tts-wav/4.wav"
_five = "assets/tts-wav/5.wav"
_six = "assets/tts-wav/6.wav"
_seven = "assets/tts-wav/7.wav"
_eight = "assets/tts-wav/8.wav"
_nine = "assets/tts-wav/9.wav"


_ok = "assets/tts-wav/ok.wav"

def playAudio(_file):
	os.system("aplay " + _file)


#---------------------------------------------------UDP_Client--------------------------------------------------------
def udp_client(message):
    output = ""
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_address = ('localhost', 23456)
    #message = input('Enter command: ')
    client_socket.sendto(message.encode('utf-8'), server_address)
    data, server_address = client_socket.recvfrom(1024)
    reply_message = data.decode('utf-8')
    output = reply_message
    print('Received reply from OBC: ',reply_message)
    client_socket.close()
    playOutput(message,output)
#---------------------------------------------------------------------------------------------------------------------
    
#-----------------------------------------------------Play_Audio------------------------------------------------------
global t
t = 0.5

def playAudio(_file):
	os.system("aplay " + _file)


def playDigitAudio(num):
	num = int(num)
	numDict = {0: _zero, 1: _one, 2: _two, 3: _three, 4: _four, 5: _five, 6: _six, 7: _seven, 8: _eight, 9: _nine}
	arr = []
	while num != 0:
		arr.append(num%10)
		num //= 10
		
	for i in reversed(range(len(arr))):
		playAudio(numDict[int(arr[i])])


def playOkNotOkAudio(flag):
	if flag:
		# play audio: ok
		playAudio(_ok)
	else:
		playAudio(_not)
		playAudio(_ok)


def MLPUtil(device, _device, flag, ver, rev, date):
	playAudio(_device)
	playAudio(_pbit)
	playAudio(_check)
	sleep(t)

	playAudio(_pbit)
	playAudio(_result)
	playOkNotOkAudio(flag)
	sleep(t)

	playAudio(_sw)
	playAudio(_version)
	playDigitAudio(ver)
	sleep(t)

	playAudio(_sw)
	playAudio(_revision)
	playDigitAudio(rev)
	sleep(t)
	
	playAudio(_sw)
	playAudio(_date)
	playDigitAudio(date)

	
def IAMUtil(device, _device, flag, ver, rev, date):
	playAudio(_device)
	playAudio(_pbit)
	playAudio(_check)
	sleep(t)
	
	playAudio(_pbit)
	playAudio(_result)
	playOkNotOkAudio(flag)
	sleep(t)
	
	playAudio(_sw)
	playAudio(_version)
	playDigitAudio(ver)
	sleep(t)
	
	playAudio(_sw)
	playAudio(_revision)
	playDigitAudio(rev)
	sleep(t)
	
	playAudio(_sw)
	playAudio(_date)
	playDigitAudio(date)
	sleep(t)
	
	playAudio(_cpu)
	playOkNotOkAudio(flag)
	sleep(t)
	
	playAudio(_sdram)
	playOkNotOkAudio(flag)
	sleep(t)
	
	playAudio(_ace_ram)
	playDigitAudio(1)
	playOkNotOkAudio(flag)
	sleep(t)
	
	playAudio(_ace_ram)
	playDigitAudio(2)
	playOkNotOkAudio(flag)


def MLP(flag, ver, rev, date):
	MLPUtil("MLP", _mlp, flag, ver, rev, date)

	
def IAM(flag, ver, rev, date):
	IAMUtil("IAM", _iam, flag, ver, rev, date)


def playOutput(message,output): 

    commandList = {1: MLP, 2: IAM}
    selection = 1
    if message[0] == "I":
      selection = 2

    flag = 1
    if output =="System Error!":
         flag = 0         

    
    today = "20240122"
	# selection = int(input("command: ")) # 1 or 2
	# flag = int(input("status: ")) # 0 or 1
    ver = random.randint(0,9) # any int
    rev = random.randint(10,99) # any int
    # date = input("date: ") # any int
    if selection > 0 and selection <= len(commandList):
         commandList[selection](flag, ver, rev, today)


#---------------------------------------------------------------------------------------------------------------------
def main():

    deviceList = ["MLP", "IAM"]
    commandList = ["PBIT CHECK"]

    exitCommand = "exit"
    
    phrase_time = None
    last_sample = bytes()
    data_queue = Queue()
    recorder = sr.Recognizer()
    recorder.energy_threshold = 2000
    recorder.dynamic_energy_threshold = False

    if 'linux' in platform:
        mic_name = 'pulse'
        for index, name in enumerate(sr.Microphone.list_microphone_names()):
            if mic_name in name:
                source = sr.Microphone(sample_rate=16000, device_index=index)
                break
    else:
        source = sr.Microphone(sample_rate=16000)

    model = "base.en"                           # tiny, base, small, medium, large
    audio_model = whisper.load_model(model)

    record_timeout = 2
    phrase_timeout = 3

    temp_file = NamedTemporaryFile().name

    with source:
        recorder.adjust_for_ambient_noise(source)

    def record_callback(_, audio:sr.AudioData):
        data = audio.get_raw_data()
        data_queue.put(data)

    recorder.listen_in_background(source, record_callback, phrase_time_limit=record_timeout)

    print("Model loaded.\n")
    
    flag = True
    while True:
        try:
            transcription = ['']
            now = datetime.utcnow()
            
            if not data_queue.empty():
                phrase_complete = False
                
                if phrase_time and now - phrase_time > timedelta(seconds=phrase_timeout):
                    last_sample = bytes()
                    phrase_complete = True
                    
                phrase_time = now

                while not data_queue.empty():
                    data = data_queue.get()
                    last_sample += data

                audio_data = sr.AudioData(last_sample, source.SAMPLE_RATE, source.SAMPLE_WIDTH)
                wav_data = io.BytesIO(audio_data.get_wav_data())

                with open(temp_file, 'w+b') as f:
                    f.write(wav_data.read())
                if flag:
                    playAudio(_ok)
                    flag = False
                result = audio_model.transcribe(temp_file, fp16=torch.cuda.is_available(), prompt = "MLP PBIT check, IAM PBIT check, MLP PBIT check, IAM PBIT check")
                text = result['text'].strip()

                if phrase_complete:
                    transcription.append(text)
                else:
                    transcription[-1] = text

                os.system('cls' if os.name=='nt' else 'clear')

                print("current Transcription: ")
                for line in transcription:
                    print("orginial: ", line)
                    line = line.lower()
                    line = line.replace(" ","")
                    if SequenceMatcher(None, exitCommand, line).ratio() > 0.8:
                        raise KeyboardInterrupt
                    for device in deviceList:
                        similarity = SequenceMatcher(None, device.lower(), line[0:3]).ratio()
                        if similarity > 0.5:
                            for command in commandList:
                                similarity = SequenceMatcher(None,command.replace(" ","").lower(), line[4:]).ratio()
                                if similarity > 0.3:
                                    output = device + " " + command
                                    print(device, command)
                                    raise KeyboardInterrupt
                print("Command Not Recognized")
                sleep(0.25)
        except KeyboardInterrupt:
            break

    print("\n\nTranscription:")
    # to be sent over UDP
    print(output)
    udp_client(output)


if __name__ == "__main__":
    main()
