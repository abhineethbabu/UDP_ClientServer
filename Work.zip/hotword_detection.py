from pocketsphinx import LiveSpeech
import os

# '''	

speech = LiveSpeech(keyphrase='see see', kws_threshold=1e-10)

# asr_method = "asr_pocket_sphinx"
asr_method = "asr_whisper_ai"

print("Listening for hotword...")
for phrase in speech:
	print(phrase.segments(detailed=True))
	os.system("python3 " + asr_method + ".py")
	exit()
# '''
